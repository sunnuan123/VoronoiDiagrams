import pandas as pd
import numpy as np

import os, sys
sys.path.append(os.path.abspath(".."))
from CleanData.BaiduToWgs84 import bd09_to_wgs84


def getLatLong(path):
    with open(path, 'r+', encoding='utf-8') as f:
        lines = f.readlines()
    rows = []
    for line in lines:
        res = line.strip().split(',')
        rows.append(res)
    data = pd.DataFrame(rows)
    df = data[[3, 4]]
    df = df.rename(columns={3:'lng', 4:'lat'})
    df = df.drop_duplicates().reset_index(drop=True)
    df = df.astype(np.float64)
    return df.values



def f_Narror_coor_nodes(data):
    '''
    缩小生成后的网格缩的区域
    :param data:
    :return:
    '''
    path = '../data/border.csv'
    border = pd.read_csv(path, header=None)
    info = border.describe()
    z_min = info.loc[['min'], :].values.ravel()
    min_lng, min_lat = z_min[0] - 0.01, z_min[1] - 0.01
    z_max = info.loc[['max'], :].values.ravel()
    max_lng, max_lat = z_max[0] + 0.01, z_max[1] + 0.01

    data = data[(min_lng <= data['lng1']) & (data['lng1'] <= max_lng)]
    data = data[(min_lng <= data['lng2']) & (data['lng2'] <= max_lng)]

    data = data[(min_lat <= data['lat1']) & (data['lat1'] <= max_lat)]
    data = data[(min_lat <= data['lat2']) & (data['lat2'] <= max_lat)].reset_index(drop=True)
    return data

def solve_border(path):
    '''
    经纬度数据转84数据，并排序
    :param path:
    :return:
    '''
    data = pd.read_csv(path, header=None)
    data = data.sort_values(by=3, ascending=True)
    data = bd09_to_wgs84(data)
    data = data.drop_duplicates().reset_index(drop=True)
    return data

def narror_origin_data(path1, path2):
    '''
    缩小原始的基站点的经纬度区域，找到划定区域边界的经纬度范围，然后在此基础上扩充0.01
    path1:需要缩小区域的经纬度坐标 ../data/channel_cell_466402488_5km.txt
    path2:划定的边界区域../data/polygon_area_city.txt
    :param data:
    :return:
    '''
    #查找划定区域边界的经纬度的最大最小值，并扩充该区域
    border = solve_border(path2)
    info = border.describe()
    z_min = info.loc[['min'], :].values.ravel()
    min_lng, min_lat = z_min[0] - 0.01, z_min[1] - 0.01
    z_max = info.loc[['max'], :].values.ravel()
    max_lng, max_lat = z_max[0] + 0.01, z_max[1] + 0.01

    data = pd.read_csv(path1, header=None)
    data = data[(min_lng <= data.iloc[:,3]) & (data.iloc[:,3] <= max_lng)]
    data = data[(min_lat <= data.iloc[:,4]) & (data.iloc[:,4] <= max_lat)].reset_index(drop=True)
    data = data.iloc[:,[3,4]].rename(columns={3:'lng', 4:'lat'})
    return data.values

def narror_coor_nodes_data(path):
    '''
    :param data:
    :return:
    '''
    #查找边界的最大最小值并扩充区域
    path2 = '../data/polygon_area_city.txt'
    border = solve_border(path2)
    info = border.describe()
    z_min = info.loc[['min'], :].values.ravel()
    min_lng, min_lat = z_min[0] - 0.01, z_min[1] - 0.01
    z_max = info.loc[['max'], :].values.ravel()
    max_lng, max_lat = z_max[0] + 0.01, z_max[1] + 0.01

    data = pd.read_csv(path, index_col=0)
    data = data[(min_lng <= data.iloc[:,0]) & (data.iloc[:,0] <= max_lng)]
    data = data[(min_lng <= data.iloc[:, 2]) & (data.iloc[:, 2] <= max_lng)]
    data = data[(min_lat <= data.iloc[:, 1]) & (data.iloc[:, 1] <= max_lat)]
    data = data[(min_lat <= data.iloc[:,3]) & (data.iloc[:,3] <= max_lat)].reset_index(drop=True)
    return data





# path = '../data/polygon_area_city.txt'
# data = solve_border(path)
# print(data)

# data = narror_origin_data('../data/channel_cell_466402488_5km.txt')
# print(data)



# path = '../data/polygon_area_city.txt'
#
# solve_border(path)

