# import numpy as np
# import pandas as pd
#
# data = pd.read_csv('../data/coor_nodes.csv', index_col=0)
# print(pd.concat([data['lng1'],data['lng2']],axis=0).reset_index(drop=True))
