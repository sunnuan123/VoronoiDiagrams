from scipy.spatial import Delaunay,ConvexHull,KDTree,Voronoi,voronoi_plot_2d
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

def getDelaunayTriangulations(points):
    '''
    给定点画出delaunay三角剖分
    :return:
    '''
    tri = Delaunay(points)

    plt.triplot(points[:, 0], points[:, 1], tri.simplices)
    plt.plot(points[:, 0], points[:, 1], 'o')

    for j, p in enumerate(points):
        plt.text(p[0] - 0.03, p[1] + 0.03, j, ha='right')  # label the points
    for j, s in enumerate(tri.simplices):
        p = points[s].mean(axis=0)
        plt.text(p[0], p[1], '#%d' % j, ha='center')  # label triangles
    # plt.xlim(-0.5, 1.5)
    # plt.ylim(-0.5, 1.5)
    plt.show()
    nodes_tri = []
    for index, v in enumerate(tri.simplices):
        nodes_tri.append(points[v].tolist())
    print(nodes_tri)
    return tri

def getConvexHulls(points):
    '''
    生成凸多边形边界
    :param points:
    :return:
    '''
    hull = ConvexHull(points)
    plt.plot(points[:, 0], points[:, 1], 'o')
    for simplex in hull.simplices:
        plt.plot(points[simplex, 0], points[simplex, 1], 'k-')
    plt.show()
    return hull


def getCloestByKDTree(points,pmin,pmax):
    """
    通过KDTree获取最小距离的点
    :param points:
    :param pmin:
    :param pmax:
    :return:
    """
    tree = KDTree(points)
    x = np.linspace(pmin,pmax, 31)
    y = np.linspace(pmin,pmax, 33)
    xx, yy = np.meshgrid(x, y)
    xy = np.c_[xx.ravel(), yy.ravel()]
    dx_half, dy_half = np.diff(x[:2])[0] / 2., np.diff(y[:2])[0] / 2.
    x_edges = np.concatenate((x - dx_half, [x[-1] + dx_half]))
    y_edges = np.concatenate((y - dy_half, [y[-1] + dy_half]))
    plt.pcolormesh(x_edges, y_edges, tree.query(xy)[1].reshape(33, 31), shading='flat')
    plt.plot(points[:, 0], points[:, 1], 'ko')
    plt.show()

    return tree
def getVoronoiDiagram(points):
    '''
    画出Voronoi图
    :param points:
    :return:
    '''
    vor = Voronoi(points)
    # voronoi图的顶点
    vertices = vor.vertices
    # 组成的区域
    region_bounded = []
    regions = vor.regions
    for r in regions:
        if np.all(np.array(r) >= 0):
            region_bounded.append(vertices[r].tolist())
    df = pd.DataFrame(region_bounded,columns=['node'+str(i) for i in range(9)]).reset_index(drop=True)
    df.to_csv('../data/voronoi_nodes.csv')


    #分割区域的脊
    ridge_vertices = vor.ridge_vertices
    # 垂直于脊的直线对应的两个点，voronoi脊垂直于在输入点之间绘制的线。
    ridge_points = vor.ridge_points
    #Voronoi图的顶点图和原始点的顶点图
    plt.plot(points[:, 0], points[:, 1], 'o')
    for j, p in enumerate(points):
        plt.text(p[0] - 0.0001, p[1] + 0.0001, j, ha='right')  # label the points

    plt.plot(vor.vertices[:, 0], vor.vertices[:, 1], '*')
    for j, p in enumerate(vor.vertices):
        plt.text(p[0] - 0.0001, p[1] + 0.0001, j, ha='right')  # label the points
    plt.xlim(points.min(0)[0]-0.05, points.max(0)[0]+0.023)
    plt.ylim(points.min(0)[1]-0.023, points.max(0)[1]+0.05)
    coor_nodes = []
    # 画出有边界的脊
    for simplex in vor.ridge_vertices:
        simplex = np.asarray(simplex)
        if np.all(simplex >= 0):
            plt.plot(vor.vertices[simplex, 0], vor.vertices[simplex, 1], 'k-')
            n1 = vor.vertices[simplex[0]].tolist()
            n2 = vor.vertices[simplex[1]].tolist()
            coor_nodes.append([n1, n2])
    # 画出无边界的脊
    center = points.mean(axis=0)
    for pointidx, simplex in zip(vor.ridge_points, vor.ridge_vertices):
        simplex = np.asarray(simplex)
        if np.any(simplex < 0):
            i = simplex[simplex >= 0][0]  # finite end Vo-ronoi vertex
            t = points[pointidx[1]] - points[pointidx[0]]  # tangent切线
            t = t / np.linalg.norm(t) #求向量t的二范数
            n = np.array([-t[1], t[0]])  # normal
            midpoint = points[pointidx].mean(axis=0)
            far_point = vor.vertices[i] + np.sign(np.dot(midpoint - center, n)) * n
            plt.plot([vor.vertices[i, 0], far_point[0]],
                     [vor.vertices[i, 1], far_point[1]], 'k--')
            n1 = [vor.vertices[i, 0].tolist(), vor.vertices[i, 1].tolist()]
            n2 = [far_point[0].tolist(), far_point[1].tolist()]
            coor_nodes.append([n1,n2])
    b = pd.DataFrame(columns=['lng1', 'lat1', 'lng2', 'lat2'])
    for j in coor_nodes:
        b = b.append([{'lng1': j[0][0], 'lat1': j[0][1], 'lng2': j[1][0], 'lat2': j[1][1]}], ignore_index=True)
    b.to_csv('../data/ridge_points.csv')
    plt.show()
    return b

