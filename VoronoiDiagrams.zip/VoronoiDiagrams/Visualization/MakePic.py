# coding=utf-8


import re
import folium
import pandas as pd
import os, sys
sys.path.append(os.path.abspath(".."))
from CleanData.PreSloveData import narror_origin_data, solve_border, narror_coor_nodes_data
from Voronoi.GetAreaNodesLatLng import get_inter_nodes_area


def replace_html(fileName, flag):
    with open(fileName, 'r', encoding='utf-8') as f:
        files = f.read()
    link_css = re.findall(r'<link rel.+?/>', files)
    link_js = re.findall(r'<script src=.+?</script>', files)
    if flag:
        list_js = [f'<script src="js_data/leaflet.js"></script>',
                   '<script src="js_data/jquery-1.12.4.min.js"></script>',
                   '<script src="js_data/bootstrap.min.js"></script>',
                   '<script src="js_data/leaflet.awesome-markers.js"></script>',
                   '<script src="js_data/leaflet-ant-path.min.js"></script>']
        list_css = ['<link rel="stylesheet" href="css_data/leaflet.css"/>',
                    '<link rel="stylesheet" href="css_data/bootstrap.min.css"/>',
                    '<link rel="stylesheet" href="css_data/bootstrap-theme.min.css"/>',
                    '<link rel="stylesheet" href="css_data/font-awesome.min.css"/>',
                    '<link rel="stylesheet" href="css_data/leaflet.awesome-markers.css"/>',
                    '<link rel="stylesheet" href="css_data/leaflet.awesome.rotate.min.css"/>']
    else:
        list_js = [f'<script src="js_data/leaflet.js"></script>',
                   '<script src="js_data/jquery-1.12.4.min.js"></script>',
                   '<script src="js_data/bootstrap.min.js"></script>',
                   '<script src="js_data/leaflet.awesome-markers.js"></script>',
                   '<script src="js_data/leaflet-ant-path.min.js"></script>']
        list_css = ['<link rel="stylesheet" href="css_data/leaflet.css"/>',
                    '<link rel="stylesheet" href="css_data/bootstrap.min.css"/>',
                    '<link rel="stylesheet" href="css_data/bootstrap-theme.min.css"/>',
                    '<link rel="stylesheet" href="css_data/font-awesome.min.css"/>',
                    '<link rel="stylesheet" href="css_data/leaflet.awesome-markers.css"/>',
                    '<link rel="stylesheet" href="css_data/leaflet.awesome.rotate.min.css"/>']
    dic = {}
    for k in range(len(link_css)):
        dic[link_css[k]] = list_css[k]
    for k in range(len(link_js)):
        dic[link_js[k]] = list_js[k]
    for k in dic.keys():
        files = files.replace(k, dic[k])
    with open(fileName, 'w', encoding='utf-8') as f:
        f.write(files)

def get_picture(path1, path2, path3,path4):
    data_1 = narror_coor_nodes_data(path1)
    data_2 = solve_border(path2)
    bj_map = folium.Map()
    # 画脊线
    for i in data_1.values:
        folium.PolyLine(
            locations=[[i[1], i[0]], [i[3], i[2]]],
            popup='The Waterfront',
            color='red',
            smooth_factor=1.2
        ).add_to(bj_map)
    # 画边界
    dataList2 = data_2.values.tolist()
    for i in range(1, len(dataList2)):
        folium.PolyLine(
            locations=[[dataList2[i - 1][1], dataList2[i - 1][0]], [dataList2[i][1], dataList2[i][0]]],
            popup='The Waterfront',
            color='blue',
            smooth_factor=1.2
        ).add_to(bj_map)
    # 画选中的区域边框
    insect_nodes = get_inter_nodes_area(path4, path2)['nodes']
    nodes = []
    #将第一个点加到最后，使其首尾相连
    for node in insect_nodes.values.tolist():
        node.insert(len(node), node[0])
        nodes.append(node)

    for row in nodes:
        for i in range(1, len(row)):
            folium.PolyLine(
                locations=[[row[i - 1][1], row[i - 1][0]], [row[i][1], row[i][0]]],
                popup='The Waterfront',
                color='black',
                smooth_factor=1.2
            ).add_to(bj_map)

    # 画泰森多边形边框内的基站点
    res = pd.read_csv('../data/res.csv')[['lng', 'lat']]
    for i, d in res.iterrows():
        folium.Marker(
            location=[float(d[1]), float(d[0])],
            popup=f'{[d[1], d[0]]}',
            # icon=folium.Icon(color='black', icon='info-sign')
            icon=folium.CustomIcon("./icon_image.jpg",
                                   icon_size=(20, 20),
                                   icon_anchor=(20, 20), )

        ).add_to(bj_map)
    bj_map.save("11.html")
    replace_html("11.html", 1)

if __name__ == '__main__':
    path1 = '../data/ridge_points.csv'
    path2 = '../data/polygon_area_city.txt'
    path3 = "../data/channel_cell_466402488_5km.txt"
    path4 = '../data/voronoi_nodes.csv'
    get_picture(path1, path2, path3, path4)


