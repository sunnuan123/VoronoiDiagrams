import numpy as np
import time

import pandas as pd
import math
import os, sys
sys.path.append(os.path.abspath(".."))
from CleanData.PreSloveData import narror_origin_data, solve_border, narror_coor_nodes_data
from shapely.geometry import Point
from shapely.geometry.polygon import Polygon


def Cal_area_2poly(data1, data2):
    """
    判断两个多边形是否相交，并计算相交的面积
    任意两个多边形相交面积的计算
    :param data1: 多边形1的经纬度点坐标
    :param data2: 多边形2的经纬度点坐标
    :return: 当前物体与待比较的物体的面积交集
    """
    poly1 = Polygon(data1)  # Polygon：多边形对象
    poly2 = Polygon(data2)
    if not poly1.intersects(poly2):
        inter_area = 0  # 如果两四边形不相交
    else:
        inter_area = poly1.intersection(poly2).area  # 相交面积
    return inter_area

def get_border_nodes(border_path):
    '''
    获取划定边界区域点的坐标
    border_path:../data/polygon_area_city.txt
    :return:
    '''
    #转84坐标系，并排序
    data = solve_border(border_path)
    border_nodes = []
    for idx, row in data.iterrows():
        border_nodes.append([row[0], row[1]])
    return border_nodes


def get_polygon(area_nodes_path):
    '''
    获取与边界点发生相交的泰森多边形的区域坐标
    area_nodes_path:给定重叠区域的多边点的坐标路径
    :return:清洗后的相交区域的点的坐标
    '''
    nodes = pd.read_csv(area_nodes_path, index_col=0).fillna(0)
    d1 = []
    for idx, row in nodes.iterrows():
        d2 = []
        for r in row:
            if 0 != r:
                res = r[1:-1].split(',')
                d3 = [float(res[0].strip()), float(res[1].strip())]
                d2.append(d3)
        d1.append(d2)
    return d1


def get_insect_area(path1, path2):
    '''
    根据相交区域的点的坐标,获取相交的面积
    :return:
    '''
    #处理相交区域的点坐标，使其规范化
    insect_nodes = get_polygon(path1)
    #获取给定边界区域的坐标
    border_area = get_border_nodes(path2)
    res = []
    for idx, nodes in enumerate(insect_nodes):
        inter_area = Cal_area_2poly(nodes, border_area)
        res.append([idx, inter_area, nodes])

    # insect_nodes = pd.DataFrame(insect_nodes)
    #idx为对应原始区域的索引
    res = pd.DataFrame(res, columns=['idx','intersect_area', 'nodes'])
    res = res[res['intersect_area'] != 0].reset_index(drop=True)
    return res

def ComputeArea(data):
    '''
    根据经纬度求实际的多边形面积
    :param data:
    :return:
    '''
    arr_len = len(data)
    if arr_len < 3:
        return 0.0
    s = data[0][1] * (data[arr_len -1][0]-data[1][0])
    for i in range(1,arr_len):
        s += data[i][1] * (data[i-1][0] - data[(i+1)%arr_len][0])
    return round(math.fabs(s/2)*9101160000.085981,6)

def get_inter_nodes_area(path1, path2):
    '''
    获取边界区域和泰森多边形有相交的多边形的坐标点
    path1:相交区域点的泰森多边形的点坐标
    path2:#边界区域点的坐标
    :return:
    '''
    res = get_insect_area(path1, path2)#获取相交的面积
    nodes = []
    # 将第一个点加到最后，使其首尾相连
    for node in res['nodes'].values.tolist():
        node.insert(len(node), node[0])
        nodes.append(node)
    #实际面积的计算
    r = []
    for n in nodes:
        r.append(ComputeArea(n))
    res['polygon_area'] = r
    return res


def getRes(path1, path2, path3):
    '''
    判断是否在多边形内
    path1:所有基站点位置的经纬度如'../data/channel_cell_466402488_5km.txt'
    :return:
    '''
    narror_orign_data = narror_origin_data(path1, path2)
    orign_data = pd.DataFrame(narror_orign_data)
    # 相交区域的泰森多边形坐标点
    insect_nodes = get_inter_nodes_area(path3, path2)
    # dd, z = get_inter_nodes()
    selected_nodes = []
    for idx, row in orign_data.iterrows():
        for i, d in enumerate(insect_nodes['nodes']):
            p = Point(row[0], row[1])
            polygon = Polygon(d)
            if polygon.contains(p):
                selected_nodes.append([i, round(row[0],5), round(row[1],5)])
    selected_nodes = pd.DataFrame(selected_nodes, columns=['idx','lng','lat']).drop_duplicates().reset_index(drop=True)
    selected_nodes.set_index('idx', inplace=True)
    res = selected_nodes.join(insect_nodes)
    res = res.drop(columns=['idx']).reset_index(drop=True)
    return res

 #所有的基站点位置经纬度
path1 = '../data/channel_cell_466402488_5km.txt'
path2 = '../data/polygon_area_city.txt'
path3 = '../data/voronoi_nodes.csv'
res = getRes(path1, path2, path3)
res.to_csv('../data/res.csv')

