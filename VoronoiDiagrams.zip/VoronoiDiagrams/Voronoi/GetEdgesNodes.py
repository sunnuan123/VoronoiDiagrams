import os
import sys
sys.path.append(os.path.abspath('..'))
from Utils.MyUtils import getDelaunayTriangulations, getConvexHulls, getCloestByKDTree,getVoronoiDiagram
from CleanData.PreSloveData import narror_origin_data


def get_coor_nodes(path1, path2):
    data = narror_origin_data(path1, path2)
    getVoronoiDiagram(data)

path1 = "../data/channel_cell_466402488_5km.txt"
path2 = '../data/polygon_area_city.txt'

get_coor_nodes(path1, path2)






